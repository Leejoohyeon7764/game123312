export default [{
  id: 208,
  name: 'Candle light',
  examine: 'This light source keeps the walls lit.',
}, {
  id: 231,
  name: 'Golden Plaque',
  examine: 'Scripture written from the Gods years and years ago. Feels interesting.',
  actions: ['push', 'examine'],
}];
