export default [{
  id: 'hammer',
  respawnIn: '1m 30s',
  x: 18,
  y: 113,
}];
