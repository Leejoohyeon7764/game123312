<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Terrain" tilewidth="32" tileheight="32" tilecount="252" columns="9">
 <image source="../../../src/assets/tiles/terrain.png" width="288" height="896"/>
</tileset>
