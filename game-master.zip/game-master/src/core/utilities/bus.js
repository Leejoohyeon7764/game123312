import Vue from 'vue';

/**
 * Event bus
 */
const bus = new Vue();

export default bus;
