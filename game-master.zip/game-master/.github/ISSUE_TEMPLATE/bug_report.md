---
name: Bug report
about: Create a report to help us improve

---

<!-- Please don't delete this template or we'll close your issue -->
<!-- Before creating an issue please make sure you are using the latest version of the game. -->
**What is the current behavior?**

**If the current behavior is a bug, please provide the exact steps to reproduce.**

**What is the expected behavior?**

**Additional context**
Add any other context about the problem here.
